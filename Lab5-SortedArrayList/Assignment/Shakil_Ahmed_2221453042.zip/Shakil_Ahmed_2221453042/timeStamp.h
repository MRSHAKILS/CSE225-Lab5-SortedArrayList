#ifndef TIMESTAMP_H_INCLUDED
#define TIMESTAMP_H_INCLUDED

#include <iostream>

using namespace std;

class timeStamp {
private:
    int h;
    int m;
    int s;

public:
    timeStamp();
    timeStamp(int h, int m, int s);
    void printTime();
    int getHour();
    int getMinute();
    int getSec();
    void setHour(int h);
    void setMinute(int m);
    void setSec(int s);
    bool operator==(timeStamp t);
};

#endif // TIMESTAMP_H_INCLUDED
